import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.Scanner;
import org.json.JSONObject;

public class ConversorMoedas {

    // API Key gratuita da ExchangeRate-API
    private static final String API_KEY = "6b8230b0faa9074272cdcc12";
    private static final String API_URL = "https://v6.exchangerate-api.com/v6/";

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.println("╔═══════════════════════════════════════╗");
        System.out.println("║   CONVERSOR DE MOEDAS - API v2.0      ║");
        System.out.println("╚═══════════════════════════════════════╝");
        System.out.println();

        while (true) {
            exibirMoedasPopulares();

            System.out.print("\nDigite a moeda de origem (ou 'SAIR' para encerrar): ");
            String moedaOrigem = scanner.nextLine().toUpperCase().trim();

            if (moedaOrigem.equals("SAIR")) {
                System.out.println("\nObrigado por usar o Conversor de Moedas!");
                break;
            }

            System.out.print("Digite a moeda de destino: ");
            String moedaDestino = scanner.nextLine().toUpperCase().trim();

            System.out.print("Digite o valor a ser convertido: ");
            double valor;

            try {
                valor = Double.parseDouble(scanner.nextLine().replace(",", "."));

                if (valor < 0) {
                    System.out.println("O valor não pode ser negativo!");
                    continue;
                }

            } catch (NumberFormatException e) {
                System.out.println("Valor inválido!");
                continue;
            }

            System.out.println("\nBuscando taxa de câmbio atualizada...");

            try {
                double taxa = obterTaxaCambio(moedaOrigem, moedaDestino);
                double resultado = valor * taxa;

                System.out.println("\n" + "═".repeat(45));
                System.out.printf(" %.2f %s = %.2f %s%n",
                        valor, moedaOrigem, resultado, moedaDestino);
                System.out.printf("Taxa de câmbio: 1 %s = %.6f %s%n",
                        moedaOrigem, taxa, moedaDestino);
                System.out.println("Dados atualizados da ExchangeRate-API");
                System.out.println("═".repeat(45) + "\n");

            } catch (Exception e) {
                System.out.println("Erro ao obter taxa de câmbio: " + e.getMessage());
                System.out.println();
            }
        }

        scanner.close();
    }

    /**
     * Obtém a taxa de câmbio da API ExchangeRate-API
     * @param moedaOrigem Código da moeda de origem
     * @param moedaDestino Código da moeda de destino
     * @return Taxa de conversão
     * @throws Exception Se houver erro na requisição
     */
    private static double obterTaxaCambio(String moedaOrigem, String moedaDestino) throws Exception {
        String urlString = API_URL + API_KEY + "/pair/" + moedaOrigem + "/" + moedaDestino;

        URL url = new URL(urlString);
        HttpURLConnection conn = (HttpURLConnection) url.openConnection();
        conn.setRequestMethod("GET");
        conn.setConnectTimeout(5000);
        conn.setReadTimeout(5000);

        int responseCode = conn.getResponseCode();

        if (responseCode == 200) {
            BufferedReader in = new BufferedReader(new InputStreamReader(conn.getInputStream()));
            String inputLine;
            StringBuilder response = new StringBuilder();

            while ((inputLine = in.readLine()) != null) {
                response.append(inputLine);
            }
            in.close();

            JSONObject jsonResponse = new JSONObject(response.toString());

            if (jsonResponse.getString("result").equals("success")) {
                return jsonResponse.getDouble("conversion_rate");
            } else {
                throw new Exception("API retornou erro: " + jsonResponse.optString("error-type"));
            }

        } else if (responseCode == 404) {
            throw new Exception("Moeda inválida. Verifique os códigos das moedas.");
        } else {
            throw new Exception("Erro na requisição HTTP: " + responseCode);
        }
    }

    /**
     * Exibe a lista de moedas mais populares
     */
    private static void exibirMoedasPopulares() {
        System.out.println("Moedas mais populares:");
        System.out.println("─".repeat(45));
        System.out.println("USD - Dólar Americano");
        System.out.println("BRL - Real Brasileiro");
        System.out.println("EUR - Euro");
        System.out.println("GBP - Libra Esterlina");
        System.out.println("JPY - Iene Japonês");
        System.out.println("CAD - Dólar Canadense");
        System.out.println("AUD - Dólar Australiano");
        System.out.println("CHF - Franco Suíço");
        System.out.println("CNY - Yuan Chinês");
        System.out.println("ARS - Peso Argentino");
        System.out.println("MXN - Peso Mexicano");
        System.out.println("INR - Rúpia Indiana");
        System.out.println("\n Você pode usar qualquer código de moeda ISO 4217");
        System.out.println("─".repeat(45));
    }
}